package br.com.alura.linguagem.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinguagemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinguagemApiApplication.class, args);
	}

}
