package br.com.alura.linguagem.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinguagemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
